# Ordinateur de Bord (widget)

بناء الـ APK:
- **Android Studio**: File ▸ Open ▸ هذا المجلد ▸ Build ▸ Build APK(s)
- **سطر الأوامر**: `gradle assembleDebug`  (أو `./gradlew assembleDebug`)
- **من الهاتف بدون حاسوب**: ارفع المجلد إلى مستودع GitHub، ثم Actions ▸ Build APK ▸ حمّل الـ artifact.

الناتج: app/build/outputs/apk/debug/app-debug.apk
الصور في app/src/main/res/drawable-nodpi/
