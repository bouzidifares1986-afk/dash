package com.coolray.customdash;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class DashWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        startRenderService(context);
    }

    @Override
    public void onEnabled(Context context) {
        startRenderService(context);
    }

    @Override
    public void onDisabled(Context context) {
        context.stopService(new Intent(context, DashRenderService.class));
    }

    private void startRenderService(Context context) {
        Intent intent = new Intent(context, DashRenderService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }
}
