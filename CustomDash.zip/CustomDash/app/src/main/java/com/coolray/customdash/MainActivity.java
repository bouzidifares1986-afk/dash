package com.coolray.customdash;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent svc = new Intent(this, DashRenderService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
        else startService(svc);

        TextView tv = new TextView(this);
        tv.setText("Ordinateur de Bord\n\nAjoutez le widget « Ordinateur de Bord »\ndepuis l'écran d'accueil (appui long → Widgets).");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(20f);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundColor(Color.parseColor("#0A0F1A"));
        setContentView(tv);
    }
}
