package com.coolray.customdash;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.*;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.RemoteViews;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashRenderService extends Service {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Object carPropertyManager;
    private Method getIntPropMethod;
    private Method getFloatPropMethod;

    // بيانات السيارة الحية
    private String gear = "D";
    private String driveMode = "SPORT"; // SPORT, ADAPTATIF, CONFORT, ECONOMIE
    private float fuelLiters = 36.4f;
    private float tankCapacity = 45.0f;
    private int engineTemp = 95;
    private float batteryVolt = 14.0f;

    // بيانات الرحلة والإطارات
    private float tripDist = 0.0f, totalDist = 3986.5f;
    private int tripSpeed = 0, avgSpeed = 35;
    private float tripCons = 0.0f, totalCons = 7.4f;
    private int[] tireKpa = {230, 230, 230, 230};
    private int[] tireTemp = {16, 16, 16, 16};
    private int maintKm = 3491, maintMax = 10000, odoKm = 20000;

    // حجم الرسم المنطقي (كل الإحداثيات أدناه مبنية عليه) وحجم الصورة المرسلة للودجت
    private static final int LOGICAL_W = 1080, LOGICAL_H = 1440;
    private static final int OUT_W = 720, OUT_H = 960;   // أخف بكثير على Binder/RemoteViews

    private final java.util.HashMap<Integer, Bitmap> bitmapCache = new java.util.HashMap<>();
    private String lastFrameKey = null;

    private final Runnable updateLoop = new Runnable() {
        @Override
        public void run() {
            try {
                readVehicleSensors();
                pushWidgetFrame();
            } catch (Throwable ignored) {}
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotification();
        initCarApi();
        handler.post(updateLoop);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        lastFrameKey = null;   // إجبار إعادة الرسم عند إضافة ودجت جديد
        return START_STICKY;
    }

    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel("dash_ch", "Dash Widget", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
            Notification notif = new Notification.Builder(this, "dash_ch")
                    .setContentTitle("Ordinateur de Bord")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .build();
            startForeground(1, notif);
        } else {
            Notification notif = new Notification.Builder(this)
                    .setContentTitle("Ordinateur de Bord")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .build();
            startForeground(1, notif);
        }
    }

    // تحميل الصورة مرة واحدة فقط (بدل فك الترميز كل ثانية)
    private Bitmap getBmp(int resId) {
        Bitmap b = bitmapCache.get(resId);
        if (b == null) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            b = BitmapFactory.decodeResource(getResources(), resId, o);
            if (b != null) bitmapCache.put(resId, b);
        }
        return b;
    }

    private void initCarApi() {
        try {
            Class<?> carCls = Class.forName("android.car.Car");
            Method createCar = carCls.getMethod("createCar", android.content.Context.class);
            Object car = createCar.invoke(null, this);
            Method getMgr = carCls.getMethod("getCarManager", String.class);
            carPropertyManager = getMgr.invoke(car, "property");
            if (carPropertyManager != null) {
                getIntPropMethod = carPropertyManager.getClass().getMethod("getIntProperty", int.class, int.class);
                getFloatPropMethod = carPropertyManager.getClass().getMethod("getFloatProperty", int.class, int.class);
            }
        } catch (Throwable ignored) {}
    }

    private void readVehicleSensors() {
        if (carPropertyManager == null) return;
        try {
            // معرفات Android CarPropertyIds القياسية
            float fLevel = (float) getFloatPropMethod.invoke(carPropertyManager, 0x11600307, 0); // FUEL_LEVEL (ml)
            if (fLevel > 0) fuelLiters = fLevel / 1000f;

            float coolTemp = (float) getFloatPropMethod.invoke(carPropertyManager, 0x11600301, 0); // ENGINE_COOLANT_TEMP
            if (coolTemp > 0) engineTemp = Math.round(coolTemp);

            float odo = (float) getFloatPropMethod.invoke(carPropertyManager, 0x11600204, 0); // PERF_ODOMETER
            if (odo > 0) odoKm = Math.round(odo);
        } catch (Throwable ignored) {}
    }

    // تحديد لون وضع القيادة
    private int getDriveModeColor(String mode) {
        switch (mode.toUpperCase(Locale.ROOT)) {
            case "SPORT":
                return Color.parseColor("#FF2A2A"); // حمراء
            case "ADAPTATIF":
                return Color.parseColor("#00D2FF"); // أزرق سماوي
            case "CONFORT":
                return Color.parseColor("#9B51E0"); // بنفسجي
            case "ECONOMIE":
            case "ÉCONOMIE":
                return Color.parseColor("#00E676"); // أخضر
            default:
                return Color.parseColor("#00D2FF");
        }
    }

    // تحديد لون درجة حرارة المحرك
    private int getEngineTempColor(int temp) {
        if (temp <= 97) return Color.parseColor("#00B0FF");      // أزرق (< 97)
        else if (temp <= 100) return Color.parseColor("#FF9100"); // برتقالي (98 - 100)
        else return Color.parseColor("#FF1744");                  // أحمر (> 101)
    }

    private Bitmap drawDashboardBitmap(int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(OUT_W, OUT_H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.scale(OUT_W / (float) w, OUT_H / (float) h);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        int themeColor = getDriveModeColor(driveMode);

        // 1. خلفية الودجت الشفافة متأثرة بلون وضع القيادة
        int bgTint = Color.argb(135, Color.red(themeColor) / 6, Color.green(themeColor) / 6, Color.blue(themeColor) / 6);
        p.setColor(bgTint);
        canvas.drawRoundRect(new RectF(6, 6, w - 6, h - 6), 34f, 34f, p);

        // إطار نيون متوهج
        Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(4f);
        strokePaint.setColor(themeColor);
        strokePaint.setShadowLayer(12f, 0, 0, themeColor);

        // الشريط العلوي (القير + وضع القيادة + الساعة والتاريخ)
        RectF topBar = new RectF(18, 18, w - 18, 115);
        p.setColor(Color.argb(145, 8, 12, 20));
        canvas.drawRoundRect(topBar, 24f, 24f, p);
        canvas.drawRoundRect(topBar, 24f, 24f, strokePaint);

        Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        txt.setColor(Color.WHITE);
        txt.setTextSize(64f);
        canvas.drawText(gear, 55f, 88f, txt);

        txt.setColor(themeColor);
        txt.setTextSize(42f);
        canvas.drawText(driveMode, 145f, 84f, txt);

        String timeStr = new SimpleDateFormat("HH:mm", Locale.FRENCH).format(new Date());
        String dateStr = new SimpleDateFormat("dd MMMM yyyy", Locale.FRENCH).format(new Date()).toUpperCase(Locale.FRENCH);
        txt.setColor(Color.WHITE);
        txt.setTextAlign(Paint.Align.RIGHT);
        txt.setTextSize(50f);
        canvas.drawText(timeStr, w - 40f, 70f, txt);
        txt.setTextSize(22f);
        canvas.drawText(dateStr, w - 40f, 102f, txt);
        txt.setTextAlign(Paint.Align.LEFT);

        // العمود الأيسر (4 بطاقات)
        float colW = w * 0.37f;
        float startY = 132f;
        float footerH = 95f;
        float cardH = (h - startY - footerH - 36f) / 4f;

        for (int i = 0; i < 4; i++) {
            float top = startY + i * (cardH + 10f);
            RectF r = new RectF(18, top, 18 + colW, top + cardH);
            p.setColor(Color.argb(135, 10, 15, 25));
            canvas.drawRoundRect(r, 22f, 22f, p);
            canvas.drawRoundRect(r, 22f, 22f, strokePaint);
        }

        // بطاقة 1: Carburant (مضخة نفطال)
        drawCardIcon(canvas, R.drawable.ic_pump_naftal, 30, startY + 14, 130, startY + cardH - 38, null);
        drawCardValueAndLabel(canvas, String.format(Locale.US, "%.1f", fuelLiters), "L", "Carburant", 18, startY, colW, cardH, Color.WHITE, themeColor);

        // بطاقة 2: Temp. Moteur (تغير اللون حسب الشرط)
        float y2 = startY + (cardH + 10f);
        int tColor = getEngineTempColor(engineTemp);
        drawCardIcon(canvas, R.drawable.ic_temp_icon, 36, y2 + 22, 125, y2 + cardH - 42, tColor);
        drawCardValueAndLabel(canvas, engineTemp + "°", "C", "Temp. Moteur", 18, y2, colW, cardH, tColor, tColor);

        // بطاقة 3: Tension (بطارية تودور)
        float y3 = startY + 2 * (cardH + 10f);
        drawCardIcon(canvas, R.drawable.ic_battery_tudor, 28, y3 + 22, 135, y3 + cardH - 42, null);
        drawCardValueAndLabel(canvas, String.valueOf((int) batteryVolt), "V", "Tension", 18, y3, colW, cardH, Color.WHITE, themeColor);

        // بطاقة 4: Réservoir (الدلو يتغير مستوى السائل الأصفر بداخله حسب نسبة الخزان)
        float y4 = startY + 3 * (cardH + 10f);
        float fillPct = Math.max(0f, Math.min(1f, fuelLiters / tankCapacity));
        RectF canBounds = new RectF(34, y4 + 16, 130, y4 + cardH - 38);
        Paint fuelFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        fuelFill.setColor(Color.argb(220, 235, 195, 15));
        float liquidTop = canBounds.bottom - (canBounds.height() * 0.76f * fillPct);
        canvas.drawRoundRect(new RectF(canBounds.left + 8, liquidTop, canBounds.right - 8, canBounds.bottom - 6), 8f, 8f, fuelFill);
        drawCardIcon(canvas, R.drawable.ic_jerrycan_shell, canBounds.left, canBounds.top, canBounds.right, canBounds.bottom, null);
        drawCardValueAndLabel(canvas, String.valueOf((int) tankCapacity), "L", "Réservoir", 18, y4, colW, cardH, Color.WHITE, themeColor);

        // القسم الأيمن: Trajet actuel & Cumulé
        float rightX = 32f + colW;
        float rightW = w - rightX - 18f;
        float halfW = (rightW - 12f) / 2f;
        float tripH = 260f;

        drawTripBox(canvas, rightX, startY, halfW, tripH, "Trajet actuel",
                String.format(Locale.FRANCE, "%.1f km", tripDist), "0h00", tripSpeed + " km/h",
                String.format(Locale.FRANCE, "%.1f L/100", tripCons), strokePaint);

        drawTripBox(canvas, rightX + halfW + 12f, startY, halfW, tripH, "Cumulé",
                String.format(Locale.FRANCE, "%.1f km", totalDist), "112h00", avgSpeed + " km/h",
                String.format(Locale.FRANCE, "%.1f L/100", totalCons), strokePaint);

        // قسم الإطارات والسيارة
        float carSectionTop = startY + tripH + 45f;
        txt.setColor(themeColor);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(34f);
        canvas.drawText("PNEUS KPA / C°", rightX + rightW / 2f, carSectionTop, txt);

        Bitmap carBmp = getBmp(R.drawable.ic_car_top);
        if (carBmp != null) {
            // الحفاظ على نسبة أبعاد السيارة داخل المساحة المتاحة
            float availL = rightX + rightW * 0.22f, availR = rightX + rightW * 0.78f;
            float availT = carSectionTop + 20f, availB = h - footerH - 25f;
            float ar = carBmp.getWidth() / (float) carBmp.getHeight();
            float dw = availR - availL, dh = availB - availT;
            if (dw / dh > ar) { float nw = dh * ar; availL += (dw - nw) / 2f; availR = availL + nw; }
            else { float nh = dw / ar; availT += (dh - nh) / 2f; availB = availT + nh; }
            Paint carPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(carBmp, null, new RectF(availL, availT, availR, availB), carPaint);
        }

        drawTireInfo(canvas, "AVG", tireKpa[0], tireTemp[0], rightX + 45f, carSectionTop + 70f, themeColor);
        drawTireInfo(canvas, "AVD", tireKpa[1], tireTemp[1], rightX + rightW - 45f, carSectionTop + 70f, themeColor);
        drawTireInfo(canvas, "ARG", tireKpa[2], tireTemp[2], rightX + 45f, h - footerH - 120f, themeColor);
        drawTireInfo(canvas, "ARD", tireKpa[3], tireTemp[3], rightX + rightW - 45f, h - footerH - 120f, themeColor);

        // الشريط السفلي (الصيانة والعداد)
        RectF foot = new RectF(18, h - footerH, w - 18, h - 14);
        p.setColor(Color.argb(145, 8, 12, 20));
        canvas.drawRoundRect(foot, 24f, 24f, p);
        canvas.drawRoundRect(foot, 24f, 24f, strokePaint);

        txt.setTextAlign(Paint.Align.LEFT);
        txt.setColor(Color.WHITE);
        txt.setTextSize(26f);
        canvas.drawText("Entretien dans  " + maintKm + " / " + maintMax + " km", 70f, h - 46f, txt);
        txt.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("Odomètre  " + odoKm + " km", w - 40f, h - 46f, txt);

        return bmp;
    }

    private void drawCardIcon(Canvas c, int resId, float l, float t, float r, float b, Integer tint) {
        Bitmap icon = getBmp(resId);
        if (icon == null) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        if (tint != null) p.setColorFilter(new PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_IN));
        // الحفاظ على نسبة أبعاد الأيقونة وتوسيطها داخل المستطيل المطلوب
        float bw = r - l, bh = b - t, ar = icon.getWidth() / (float) icon.getHeight();
        if (bw / bh > ar) { float nw = bh * ar; l += (bw - nw) / 2f; r = l + nw; }
        else { float nh = bw / ar; t += (bh - nh) / 2f; b = t + nh; }
        c.drawBitmap(icon, null, new RectF(l, t, r, b), p);
    }

    private void drawCardValueAndLabel(Canvas c, String val, String unit, String label, float x, float y, float w, float h, int valColor, int unitColor) {
        Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        txt.setTextAlign(Paint.Align.CENTER);

        txt.setColor(valColor);
        txt.setTextSize(46f);
        c.drawText(val, x + w * 0.68f, y + h * 0.48f, txt);

        txt.setColor(unitColor);
        txt.setTextSize(28f);
        c.drawText(unit, x + w * 0.68f, y + h * 0.70f, txt);

        txt.setColor(Color.WHITE);
        txt.setTextSize(22f);
        c.drawText(label, x + w * 0.50f, y + h - 12f, txt);
    }

    private void drawTripBox(Canvas c, float x, float y, float w, float h, String title, String dist, String dur, String spd, String cons, Paint border) {
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.argb(135, 10, 15, 25));
        RectF r = new RectF(x, y, x + w, y + h);
        c.drawRoundRect(r, 22f, 22f, bg);
        c.drawRoundRect(r, 22f, 22f, border);

        Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        txt.setColor(Color.WHITE);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTextSize(28f);
        c.drawText(title, x + w / 2f, y + 36f, txt);

        String[] keys = {"Distance", "Durée", "Vitesse", "Consommation"};
        String[] vals = {dist, dur, spd, cons};
        txt.setTextSize(22f);
        for (int i = 0; i < 4; i++) {
            float ry = y + 82f + i * 48f;
            txt.setTextAlign(Paint.Align.LEFT);
            c.drawText(keys[i], x + 16f, ry, txt);
            txt.setTextAlign(Paint.Align.RIGHT);
            c.drawText(vals[i], x + w - 16f, ry, txt);
        }
    }

    private void drawTireInfo(Canvas c, String label, int kpa, int temp, float cx, float cy, int accent) {
        Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
        txt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setColor(Color.LTGRAY);
        txt.setTextSize(22f);
        c.drawText(label, cx, cy, txt);

        txt.setColor(Color.WHITE);
        txt.setTextSize(30f);
        c.drawText(String.valueOf(kpa), cx, cy + 32f, txt);

        txt.setColor(accent);
        txt.setTextSize(26f);
        c.drawText(temp + "°", cx, cy + 60f, txt);
    }

    private void pushWidgetFrame() {
        AppWidgetManager mgr = AppWidgetManager.getInstance(this);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(this, DashWidgetProvider.class));
        if (ids == null || ids.length == 0) return;

        // لا نعيد الرسم/الإرسال إلا إذا تغيّرت القيم أو الدقيقة
        String key = new SimpleDateFormat("yyyyMMddHHmm", Locale.US).format(new Date()) + "|" + gear + driveMode
                + fuelLiters + tankCapacity + engineTemp + batteryVolt + tripDist + totalDist + tripSpeed + avgSpeed
                + tripCons + totalCons + java.util.Arrays.toString(tireKpa) + java.util.Arrays.toString(tireTemp)
                + maintKm + maintMax + odoKm + "|" + java.util.Arrays.toString(ids);
        if (key.equals(lastFrameKey)) return;
        lastFrameKey = key;

        Bitmap frame = drawDashboardBitmap(LOGICAL_W, LOGICAL_H);
        for (int id : ids) {
            RemoteViews views = new RemoteViews(getPackageName(), R.layout.dash_widget);
            views.setImageViewBitmap(R.id.widget_canvas_view, frame);
            mgr.updateAppWidget(id, views);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(updateLoop);
        super.onDestroy();
    }
}
