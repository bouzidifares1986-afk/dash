package com.coolray.customdash;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.*;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.RemoteViews;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashRenderService extends Service {

    // ===== إعدادات المظهر =====
    // false = الإطارات زرقاء دائماً كما في التصميم (لون وضع القيادة يظهر على الكلمة SPORT فقط)
    // true  = الإطارات تتبع لون وضع القيادة
    private static final boolean FRAME_FOLLOWS_MODE = false;

    // الرسم يتم على إحداثيات صورة التصميم 864x1219
    private static final int LOGICAL_W = 864, LOGICAL_H = 1219;
    private static final int OUT_W = 720, OUT_H = 1016;      // حجم الصورة المرسلة للودجت (خفيف على Binder)

    private static final int BLUE = 0xFF1E90FF;
    private static final int CYAN = 0xFF22D3F5;
    private static final int LIGHT_BLUE = 0xFF5BC8F5;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Object carPropertyManager;
    private Method getIntPropMethod;
    private Method getFloatPropMethod;

    // بيانات السيارة الحية
    private String gear = "D";
    private String driveMode = "SPORT"; // SPORT, ADAPTATIF, CONFORT, ECONOMIE
    private float fuelLiters = 36.4f;
    private float tankCapacity = 45.0f;
    private int engineTemp = 95;
    private float batteryVolt = 14.0f;

    // بيانات الرحلة والإطارات
    private float tripDist = 0.0f, totalDist = 3986.5f;
    private int tripSpeed = 0, avgSpeed = 35;
    private float tripCons = 0.0f, totalCons = 7.4f;
    private int[] tireKpa = {230, 230, 230, 230};
    private int[] tireTemp = {16, 16, 16, 16};
    private int maintKm = 3491, maintMax = 10000, odoKm = 20000;

    private final java.util.HashMap<Integer, Bitmap> bitmapCache = new java.util.HashMap<>();
    private String lastFrameKey = null;

    private final Runnable updateLoop = new Runnable() {
        @Override
        public void run() {
            try {
                readVehicleSensors();
                pushWidgetFrame();
            } catch (Throwable ignored) {}
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotification();
        initCarApi();
        handler.post(updateLoop);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        lastFrameKey = null;   // إجبار إعادة الرسم عند إضافة ودجت جديد
        return START_STICKY;
    }

    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel("dash_ch", "Dash Widget", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
            Notification notif = new Notification.Builder(this, "dash_ch")
                    .setContentTitle("Ordinateur de Bord")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .build();
            startForeground(1, notif);
        } else {
            Notification notif = new Notification.Builder(this)
                    .setContentTitle("Ordinateur de Bord")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .build();
            startForeground(1, notif);
        }
    }

    // تحميل الصورة مرة واحدة فقط
    private Bitmap getBmp(int resId) {
        Bitmap b = bitmapCache.get(resId);
        if (b == null) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            b = BitmapFactory.decodeResource(getResources(), resId, o);
            if (b != null) bitmapCache.put(resId, b);
        }
        return b;
    }

    private void initCarApi() {
        try {
            Class<?> carCls = Class.forName("android.car.Car");
            Method createCar = carCls.getMethod("createCar", android.content.Context.class);
            Object car = createCar.invoke(null, this);
            Method getMgr = carCls.getMethod("getCarManager", String.class);
            carPropertyManager = getMgr.invoke(car, "property");
            if (carPropertyManager != null) {
                getIntPropMethod = carPropertyManager.getClass().getMethod("getIntProperty", int.class, int.class);
                getFloatPropMethod = carPropertyManager.getClass().getMethod("getFloatProperty", int.class, int.class);
            }
        } catch (Throwable ignored) {}
    }

    private void readVehicleSensors() {
        if (carPropertyManager == null) return;
        try {
            // معرفات Android CarPropertyIds القياسية
            float fLevel = (float) getFloatPropMethod.invoke(carPropertyManager, 0x11600307, 0); // FUEL_LEVEL (ml)
            if (fLevel > 0) fuelLiters = fLevel / 1000f;

            float coolTemp = (float) getFloatPropMethod.invoke(carPropertyManager, 0x11600301, 0); // ENGINE_COOLANT_TEMP
            if (coolTemp > 0) engineTemp = Math.round(coolTemp);

            float odo = (float) getFloatPropMethod.invoke(carPropertyManager, 0x11600204, 0); // PERF_ODOMETER
            if (odo > 0) odoKm = Math.round(odo);
        } catch (Throwable ignored) {}
    }

    // لون وضع القيادة
    private int getDriveModeColor(String mode) {
        switch (mode.toUpperCase(Locale.ROOT)) {
            case "SPORT":     return Color.parseColor("#FF2A2A"); // حمراء
            case "ADAPTATIF": return Color.parseColor("#00D2FF"); // أزرق سماوي
            case "CONFORT":   return Color.parseColor("#9B51E0"); // بنفسجي
            case "ECONOMIE":
            case "ÉCONOMIE":  return Color.parseColor("#00E676"); // أخضر
            default:          return Color.parseColor("#00D2FF");
        }
    }

    // لون درجة حرارة المحرك
    private int getEngineTempColor(int temp) {
        if (temp <= 97) return Color.parseColor("#19D3F3");       // أزرق سماوي (<= 97)
        else if (temp <= 100) return Color.parseColor("#FF9100"); // برتقالي (98 - 100)
        else return Color.parseColor("#FF1744");                  // أحمر (> 100)
    }

    // ================= أدوات الرسم =================

    private Typeface condBold() { return Typeface.create("sans-serif-condensed", Typeface.BOLD); }
    private Typeface condReg()  { return Typeface.create("sans-serif-condensed", Typeface.NORMAL); }

    private Paint textPaint(float size, int color, Paint.Align align, boolean bold, float skew, int glow) {
        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setTypeface(bold ? condBold() : condReg());
        t.setTextSize(size);
        t.setColor(color);
        t.setTextAlign(align);
        if (skew != 0f) t.setTextSkewX(skew);
        if (glow != 0) t.setShadowLayer(10f, 0, 0, glow);
        return t;
    }

    // تصغير الخط تلقائياً كي لا يتجاوز النص العرض المسموح (يختلف عرض الخطوط بين الأجهزة)
    private float fit(String s, float size, float maxW, boolean bold) {
        float w = textPaint(size, Color.WHITE, Paint.Align.LEFT, bold, 0f, 0).measureText(s);
        return w > maxW ? size * maxW / w : size;
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align align,
                      boolean bold, float skew, int glow) {
        c.drawText(s, x, y, textPaint(size, color, align, bold, skew, glow));
    }

    private void drawBox(Canvas c, RectF r, float rad, int frame) {
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xF20B1B38, 0xF2040A17, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, f);
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeWidth(3f);
        s.setColor(frame);
        s.setShadowLayer(12f, 0, 0, frame);
        c.drawRoundRect(r, rad, rad, s);
    }

    // الرسم على إحداثيات التصميم (864x1219) ثم التصغير إلى حجم الإخراج
    private Bitmap drawDashboardBitmap(int w, int h) {
        Bitmap bmp = Bitmap.createBitmap(OUT_W, OUT_H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        canvas.scale(OUT_W / (float) w, OUT_H / (float) h);

        int modeColor = getDriveModeColor(driveMode);
        int frame = FRAME_FOLLOWS_MODE ? modeColor : BLUE;

        // ---- الخلفية الكاملة + الإطار الخارجي المتوهج ----
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xF4081022, 0xF4020610, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(new RectF(0, 0, w, h), 40f, 40f, bg);
        Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
        outer.setStyle(Paint.Style.STROKE);
        outer.setStrokeWidth(3f);
        outer.setColor(0xFF1766C8);
        outer.setShadowLayer(14f, 0, 0, frame);
        canvas.drawRoundRect(new RectF(4, 4, w - 4, h - 4), 38f, 38f, outer);

        // ---- الشريط العلوي: (D + وضع القيادة) و (الساعة + التاريخ) ----
        Path leftTop = new Path();
        leftTop.moveTo(15, 12); leftTop.lineTo(455, 12); leftTop.lineTo(425, 112); leftTop.lineTo(15, 112); leftTop.close();
        Paint lf = new Paint(Paint.ANTI_ALIAS_FLAG);
        lf.setShader(new LinearGradient(0, 12, 0, 112, 0xF20B1B38, 0xF2040A17, Shader.TileMode.CLAMP));
        lf.setPathEffect(new CornerPathEffect(26f));
        canvas.drawPath(leftTop, lf);
        Paint ls = new Paint(Paint.ANTI_ALIAS_FLAG);
        ls.setStyle(Paint.Style.STROKE); ls.setStrokeWidth(3f); ls.setColor(frame);
        ls.setShadowLayer(12f, 0, 0, frame); ls.setPathEffect(new CornerPathEffect(26f));
        canvas.drawPath(leftTop, ls);

        text(canvas, gear, 78f, 98f, 112f, Color.WHITE, Paint.Align.LEFT, true, -0.22f, frame);
        float modeSize = 66f;
        Paint mp = textPaint(modeSize, modeColor, Paint.Align.LEFT, true, -0.22f, modeColor);
        while (mp.measureText(driveMode) > 215f && modeSize > 30f) {
            modeSize -= 2f;
            mp = textPaint(modeSize, modeColor, Paint.Align.LEFT, true, -0.22f, modeColor);
        }
        canvas.drawText(driveMode, 210f, 92f, mp);

        drawBox(canvas, new RectF(475, 12, 850, 112), 30f, frame);
        drawCalendarIcon(canvas, 510f, 60f, frame);
        String timeStr = new SimpleDateFormat("HH:mm", Locale.FRENCH).format(new Date());
        String dateStr = new SimpleDateFormat("dd MMMM yyyy", Locale.FRENCH).format(new Date()).toUpperCase(Locale.FRENCH);
        text(canvas, timeStr, 702f, 72f, fit(timeStr, 84f, 190f, true), Color.WHITE, Paint.Align.CENTER, true, -0.22f, 0);
        text(canvas, dateStr, 708f, 106f, fit(dateStr, 27f, 240f, false), Color.WHITE, Paint.Align.CENTER, false, -0.22f, 0);

        // ---- العمود الأيسر: 4 بطاقات ----
        RectF c1 = new RectF(15, 127, 332, 397);
        RectF c2 = new RectF(15, 411, 332, 613);
        RectF c3 = new RectF(15, 616, 332, 814);
        RectF c4 = new RectF(15, 830, 332, 1036);
        drawBox(canvas, c1, 30f, frame);
        drawBox(canvas, c2, 30f, frame);
        drawBox(canvas, c3, 30f, frame);
        drawBox(canvas, c4, 30f, frame);

        // 1) Carburant (مضخة نفطال)
        drawCardIcon(canvas, R.drawable.ic_pump_naftal, 38, 134, 196, 362, null);
        drawValueUnit(canvas, String.format(Locale.US, "%.1f", fuelLiters), "L", 262f, 300f, 342f, 76f, Color.WHITE, LIGHT_BLUE);
        drawCardLabel(canvas, "Carburant", c1);

        // 2) Temp. Moteur: الأيقونة بلونها الأصلي عندما يكون المحرك عادياً، وتتلوّن عند الارتفاع
        int tColor = getEngineTempColor(engineTemp);
        drawCardIcon(canvas, R.drawable.ic_temp_icon, 30, 425, 175, 572, engineTemp <= 97 ? null : tColor);
        drawValueUnit(canvas, engineTemp + "°", "C", 262f, 520f, 563f, 88f, tColor, tColor);
        drawCardLabel(canvas, "Temp. Moteur", c2);

        // 3) Tension (بطارية تودور)
        drawCardIcon(canvas, R.drawable.ic_battery_tudor, 30, 640, 228, 768, null);
        drawValueUnit(canvas, String.valueOf((int) batteryVolt), "V", 275f, 722f, 768f, 76f, Color.WHITE, LIGHT_BLUE);
        drawCardLabel(canvas, "Tension", c3);

        // 4) Réservoir (الجركن: مستوى السائل الأصفر يتغير حسب نسبة الوقود)
        drawJerrycan(canvas, 38f, 836f, 190f, 1000f);
        drawValueUnit(canvas, String.valueOf((int) tankCapacity), "L", 262f, 962f, 1005f, 76f, Color.WHITE, LIGHT_BLUE);
        drawCardLabel(canvas, "Réservoir", c4);

        // ---- Trajet actuel & Cumulé ----
        drawTripBox(canvas, new RectF(345, 127, 603, 372), "Trajet actuel",
                String.format(Locale.FRANCE, "%.1f km", tripDist), "0h00", tripSpeed + " km/h",
                String.format(Locale.FRANCE, "%.1f L/100", tripCons), frame);
        drawTripBox(canvas, new RectF(617, 127, 850, 372), "Cumulé",
                String.format(Locale.FRANCE, "%.1f km", totalDist), "112h00", avgSpeed + " km/h",
                String.format(Locale.FRANCE, "%.1f L/100", totalCons), frame);

        // ---- عنوان الإطارات ----
        Paint ln = new Paint(Paint.ANTI_ALIAS_FLAG);
        ln.setStyle(Paint.Style.STROKE); ln.setStrokeWidth(3f); ln.setColor(frame);
        ln.setShadowLayer(10f, 0, 0, frame); ln.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawLine(368f, 412f, 455f, 412f, ln);
        canvas.drawLine(728f, 412f, 842f, 412f, ln);
        text(canvas, "PNEUS KPA / C°", 592f, 426f, 40f, CYAN, Paint.Align.CENTER, true, 0f, CYAN);

        // ---- هالة زرقاء + السيارة ----
        canvas.save();
        canvas.translate(625f, 750f);
        canvas.scale(0.62f, 1f);
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setShader(new RadialGradient(0f, 0f, 345f, 0xB01E90FF, 0x001E90FF, Shader.TileMode.CLAMP));
        canvas.drawCircle(0f, 0f, 345f, glow);
        canvas.restore();

        Bitmap carBmp = getBmp(R.drawable.ic_car_top);
        if (carBmp != null) {
            float dh = 545f;
            float dw = dh * carBmp.getWidth() / (float) carBmp.getHeight();
            float cx = 625f, cy = 748f;
            Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(carBmp, null, new RectF(cx - dw / 2f, cy - dh / 2f, cx + dw / 2f, cy + dh / 2f), cp);
        }

        drawTireInfo(canvas, "AVG", tireKpa[0], tireTemp[0], 408f, 472f);
        drawTireInfo(canvas, "AVD", tireKpa[1], tireTemp[1], 812f, 472f);
        drawTireInfo(canvas, "ARG", tireKpa[2], tireTemp[2], 398f, 880f);
        drawTireInfo(canvas, "ARD", tireKpa[3], tireTemp[3], 815f, 880f);

        // ---- الشريط السفلي ----
        drawBox(canvas, new RectF(15, 1100, 850, 1190), 30f, frame);
        drawWrench(canvas, 40f, 1170f);
        int dotColor = maintKm > 1000 ? 0xFF2ECC40 : (maintKm > 300 ? 0xFFFF9100 : 0xFFFF1744);
        Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        dot.setColor(dotColor); dot.setShadowLayer(12f, 0, 0, dotColor);
        canvas.drawCircle(122f, 1146f, 12f, dot);

        String l1 = "Entretien dans";
        String v1 = maintKm + " / " + maintMax + " km";
        float fs1 = 29f;
        float need1 = textPaint(fs1, Color.WHITE, Paint.Align.LEFT, false, 0f, 0).measureText(l1)
                + textPaint(fs1, Color.WHITE, Paint.Align.LEFT, true, 0f, 0).measureText(v1) + 14f;
        if (need1 > 372f) fs1 = fs1 * 372f / need1;
        Paint lab = textPaint(fs1, Color.WHITE, Paint.Align.LEFT, false, 0f, 0);
        canvas.drawText(l1, 148f, 1156f, lab);
        text(canvas, v1, 148f + lab.measureText(l1) + 14f, 1156f, fs1, Color.WHITE, Paint.Align.LEFT, true, -0.15f, 0);

        Paint div = new Paint(Paint.ANTI_ALIAS_FLAG);
        div.setColor(0xFF2A4F8F); div.setStrokeWidth(3f);
        canvas.drawLine(540f, 1115f, 540f, 1175f, div);
        String l2 = "Odomètre", v2 = odoKm + " km";
        float fs2 = 29f;
        float need2 = textPaint(fs2, Color.WHITE, Paint.Align.LEFT, false, 0f, 0).measureText(l2)
                + textPaint(fs2, Color.WHITE, Paint.Align.LEFT, true, 0f, 0).measureText(v2) + 14f;
        if (need2 > 248f) fs2 = fs2 * 248f / need2;
        text(canvas, v2, 832f, 1156f, fs2, Color.WHITE, Paint.Align.RIGHT, true, -0.15f, 0);
        float v2w = textPaint(fs2, Color.WHITE, Paint.Align.LEFT, true, 0f, 0).measureText(v2);
        text(canvas, l2, 832f - v2w - 14f, 1156f, fs2, Color.WHITE, Paint.Align.RIGHT, false, 0f, 0);

        return bmp;
    }

    // رسم أيقونة داخل مستطيل مع الحفاظ على نسبة الأبعاد
    private void drawCardIcon(Canvas c, int resId, float l, float t, float r, float b, Integer tint) {
        Bitmap icon = getBmp(resId);
        if (icon == null) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        if (tint != null) p.setColorFilter(new PorterDuffColorFilter(tint, PorterDuff.Mode.SRC_IN));
        float bw = r - l, bh = b - t, ar = icon.getWidth() / (float) icon.getHeight();
        if (bw / bh > ar) { float nw = bh * ar; l += (bw - nw) / 2f; r = l + nw; }
        else { float nh = bw / ar; t += (bh - nh) / 2f; b = t + nh; }
        c.drawBitmap(icon, null, new RectF(l, t, r, b), p);
    }

    // الجركن: سائل أصفر بمستوى متغير داخل هيكل زجاجي شفاف
    private void drawJerrycan(Canvas c, float l, float t, float r, float b) {
        Bitmap shell = getBmp(R.drawable.ic_jerrycan_shell);
        if (shell == null) return;
        float bw = r - l, bh = b - t, ar = shell.getWidth() / (float) shell.getHeight();
        if (bw / bh > ar) { float nw = bh * ar; l += (bw - nw) / 2f; r = l + nw; }
        else { float nh = bw / ar; t += (bh - nh) / 2f; b = t + nh; }
        float w = r - l, h = b - t;

        float fillPct = Math.max(0f, Math.min(1f, fuelLiters / tankCapacity));
        float bodyL = l + w * 0.10f, bodyR = l + w * 0.91f;
        float bodyT = t + h * 0.22f, bodyB = t + h * 0.955f;
        float liquidTop = bodyB - (bodyB - bodyT) * fillPct;
        Paint fuel = new Paint(Paint.ANTI_ALIAS_FLAG);
        fuel.setShader(new LinearGradient(0, liquidTop, 0, bodyB, 0xE6F0D23A, 0xE6D9B518, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(bodyL, liquidTop, bodyR, bodyB), 10f, 10f, fuel);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(shell, null, new RectF(l, t, r, b), p);
    }

    private void drawValueUnit(Canvas c, String val, String unit, float cx, float valBase, float unitBase,
                               float valSize, int valColor, int unitColor) {
        text(c, val, cx, valBase, fit(val, valSize, 122f, true), valColor, Paint.Align.CENTER, true, 0f, valColor == Color.WHITE ? 0 : valColor);
        text(c, unit, cx, unitBase, 46f, unitColor, Paint.Align.CENTER, true, 0f, unitColor);
    }

    private void drawCardLabel(Canvas c, String label, RectF card) {
        text(c, label, (card.left + card.right) / 2f, card.bottom - 12f, fit(label, 29f, 290f, true), Color.WHITE, Paint.Align.CENTER, true, 0f, 0);
    }

    private void drawTripBox(Canvas c, RectF r, String title, String dist, String dur, String spd, String cons, int frame) {
        drawBox(c, r, 30f, frame);
        text(c, title, (r.left + r.right) / 2f, 167f, fit(title, 31f, r.width() - 24f, true), Color.WHITE, Paint.Align.CENTER, true, 0f, 0);

        String[] keys = {"Distance", "Durée", "Vitesse", "Consommation"};
        String[] vals = {dist, dur, spd, cons};
        float[] base = {214f, 259f, 304f, 349f};
        Paint sep = new Paint(Paint.ANTI_ALIAS_FLAG);
        sep.setColor(0x663D8BFF); sep.setStrokeWidth(1.5f);
        float rowSize = 26f;
        for (int i = 0; i < 4; i++) {
            float need = textPaint(26f, Color.WHITE, Paint.Align.LEFT, true, 0f, 0).measureText(keys[i] + "  " + vals[i]);
            float avail = r.width() - 28f;
            if (need > avail) rowSize = Math.min(rowSize, 26f * avail / need);
        }
        Paint kp = textPaint(rowSize, Color.WHITE, Paint.Align.LEFT, true, 0f, 0);
        Paint vp = textPaint(rowSize, Color.WHITE, Paint.Align.RIGHT, true, 0f, 0);
        for (int i = 0; i < 4; i++) {
            c.drawText(keys[i], r.left + 14f, base[i], kp);
            c.drawText(vals[i], r.right - 14f, base[i], vp);
            if (i < 3) c.drawLine(r.left + 12f, base[i] + 11f, r.right - 12f, base[i] + 11f, sep);
        }
    }

    private void drawTireInfo(Canvas c, String label, int kpa, int temp, float cx, float cy) {
        text(c, label, cx, cy, fit(label, 31f, 70f, true), 0xFFDDE6F2, Paint.Align.CENTER, true, 0f, 0);
        text(c, String.valueOf(kpa), cx, cy + 43f, fit(String.valueOf(kpa), 46f, 72f, true), Color.WHITE, Paint.Align.CENTER, true, 0f, 0);
        text(c, temp + "°", cx, cy + 82f, 42f, CYAN, Paint.Align.CENTER, true, 0f, CYAN);
    }

    private void drawCalendarIcon(Canvas c, float x, float y, int col) {
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(3.5f); s.setColor(LIGHT_BLUE);
        s.setShadowLayer(8f, 0, 0, col);
        c.drawRoundRect(new RectF(x, y, x + 56f, y + 52f), 9f, 9f, s);
        c.drawLine(x, y + 14f, x + 56f, y + 14f, s);
        c.drawLine(x + 14f, y - 6f, x + 14f, y + 6f, s);
        c.drawLine(x + 42f, y - 6f, x + 42f, y + 6f, s);
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setColor(LIGHT_BLUE);
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                c.drawRoundRect(new RectF(x + 9f + i * 14f, y + 21f + j * 10f, x + 17f + i * 14f, y + 27f + j * 10f), 1.5f, 1.5f, f);
    }

    private void drawWrench(Canvas c, float x, float y) {
        Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        s.setStyle(Paint.Style.STROKE); s.setColor(Color.WHITE); s.setStrokeCap(Paint.Cap.ROUND);
        s.setStrokeWidth(9f);
        c.drawLine(x + 2f, y - 2f, x + 34f, y - 36f, s);
        s.setStrokeWidth(7f);
        c.drawCircle(x + 42f, y - 44f, 13f, s);
        Paint gap = new Paint(Paint.ANTI_ALIAS_FLAG);
        gap.setColor(0xFF050C1A);
        c.drawCircle(x + 50f, y - 52f, 7f, gap);
    }

    private void pushWidgetFrame() {
        AppWidgetManager mgr = AppWidgetManager.getInstance(this);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(this, DashWidgetProvider.class));
        if (ids == null || ids.length == 0) return;

        // لا نعيد الرسم/الإرسال إلا إذا تغيّرت القيم أو الدقيقة
        String key = new SimpleDateFormat("yyyyMMddHHmm", Locale.US).format(new Date()) + "|" + gear + driveMode
                + fuelLiters + tankCapacity + engineTemp + batteryVolt + tripDist + totalDist + tripSpeed + avgSpeed
                + tripCons + totalCons + java.util.Arrays.toString(tireKpa) + java.util.Arrays.toString(tireTemp)
                + maintKm + maintMax + odoKm + "|" + java.util.Arrays.toString(ids);
        if (key.equals(lastFrameKey)) return;
        lastFrameKey = key;

        Bitmap frame = drawDashboardBitmap(LOGICAL_W, LOGICAL_H);
        for (int id : ids) {
            RemoteViews views = new RemoteViews(getPackageName(), R.layout.dash_widget);
            views.setImageViewBitmap(R.id.widget_canvas_view, frame);
            mgr.updateAppWidget(id, views);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(updateLoop);
        super.onDestroy();
    }
}
